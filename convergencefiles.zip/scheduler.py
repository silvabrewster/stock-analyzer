"""
Stock Convergence Scheduler v3.2
===================================
Runs analyzer at 14:00 UTC (7AM Pacific),
saves to PostgreSQL (Supabase), Google Drive,
and emails via Resend.

New in v3.2:
  - Signal alignment detection (per ticker)
  - Market regime detection (bull/bear/neutral)
  - Both stored in DB for dashboard display
"""

import schedule
import time
import os
import io
import requests as req
from datetime import datetime
import pandas as pd

EMAIL_FROM      = "onboarding@resend.dev"
EMAIL_TO        = "silvabrayden0@gmail.com"
RESEND_KEY      = os.environ.get("RESEND_KEY", "")
RUN_TIME        = "14:00"
EXCEL_LOG       = "stock_results_log.xlsx"
TOP_N           = 10
DRIVE_FOLDER_ID = "1NK1gDvWvszHPC6GS3Jmi5O9C4sr9Tn-n"
CREDENTIALS     = "credentials.json"

# ── google drive ──────────────────────────────────────────────────────────────

def get_drive_service():
    try:
        from google.oauth2 import service_account
        from googleapiclient.discovery import build
        creds = service_account.Credentials.from_service_account_file(
            CREDENTIALS, scopes=["https://www.googleapis.com/auth/drive"]
        )
        return build("drive", "v3", credentials=creds)
    except Exception as e:
        print(f"  ✗ Drive auth failed: {e}")
        return None

def find_file_in_drive(service, filename):
    try:
        results = service.files().list(
            q=f"name='{filename}' and '{DRIVE_FOLDER_ID}' in parents and trashed=false",
            fields="files(id, name)"
        ).execute()
        files = results.get("files", [])
        return files[0]["id"] if files else None
    except Exception:
        return None

def save_to_drive(df: pd.DataFrame):
    try:
        from googleapiclient.http import MediaIoBaseUpload, MediaIoBaseDownload
        service = get_drive_service()
        if not service:
            return
        today = datetime.now().strftime("%Y-%m-%d")
        top   = df.head(TOP_N).copy()
        top.insert(0, "Date", today)
        file_id = find_file_in_drive(service, EXCEL_LOG)
        if file_id:
            try:
                request    = service.files().get_media(fileId=file_id)
                buffer     = io.BytesIO()
                downloader = MediaIoBaseDownload(buffer, request)
                done = False
                while not done:
                    _, done = downloader.next_chunk()
                buffer.seek(0)
                existing = pd.read_excel(buffer)
                updated  = pd.concat([existing, top], ignore_index=True)
            except Exception:
                updated = top
        else:
            updated = top
        buffer = io.BytesIO()
        updated.to_excel(buffer, index=False)
        buffer.seek(0)
        mime  = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        media = MediaIoBaseUpload(buffer, mimetype=mime, resumable=True)
        if file_id:
            service.files().update(fileId=file_id, media_body=media).execute()
        else:
            service.files().create(
                body={"name": EXCEL_LOG, "parents": [DRIVE_FOLDER_ID]},
                media_body=media, fields="id"
            ).execute()
        print(f"  ✓ Excel log updated in Google Drive")
    except Exception as e:
        print(f"  ✗ Drive save failed: {e}")

# ── run analyzer ──────────────────────────────────────────────────────────────

def run_analyzer():
    print(f"\n[{datetime.now().strftime('%Y-%m-%d %H:%M')}] Running analyzer v3.2...")
    from analyzer import (
        build_universe, get_market_conditions,
        get_vanguard_top_holdings, get_yahoo_strong_buys,
        get_zacks_strong_buys, get_morningstar_ratings,
        get_insider_buyers, get_relative_strength,
        compute_consensus, check_sector_concentration,
        load_streaks, load_yesterday_top, save_streaks,
        get_signal_alignments,
    )

    universe      = build_universe()
    old_streaks   = load_streaks()
    yesterday_top = load_yesterday_top()
    market        = get_market_conditions()
    vanguard_w    = get_vanguard_top_holdings()
    yahoo_data    = get_yahoo_strong_buys(universe)
    zacks_buys    = get_zacks_strong_buys()
    ms_data       = get_morningstar_ratings(universe, yahoo_data=yahoo_data)
    insiders      = get_insider_buyers()
    rs            = get_relative_strength(universe)

    # Signal alignment (new in v3.2)
    print("\n[Signal Alignment] Calculating for all tickers...")
    alignments = get_signal_alignments(universe)

    df = compute_consensus(
        universe, yahoo_data, zacks_buys, ms_data,
        vanguard_w, insiders, rs, old_streaks, yesterday_top,
        alignments=alignments,
    )

    top10 = df.head(10)["Ticker"].tolist()
    save_streaks(top10, old_streaks)
    warning = check_sector_concentration(df, yahoo_data)
    return df, market, warning, alignments

# ── send email ────────────────────────────────────────────────────────────────

def send_email(df: pd.DataFrame, market: dict, warning, ai_brief: str = "", regime: dict = None):
    today  = datetime.now().strftime("%B %d, %Y")
    top    = df.head(TOP_N)
    sp     = market.get("sp500", {})
    vix    = market.get("vix", {})
    tny    = market.get("tny", {})
    sp_chg = sp.get("chg", 0) or 0
    sp_color = "#2d6a2d" if sp_chg >= 0 else "#8b1a1a"
    sp_arrow = "▲" if sp_chg >= 0 else "▼"

    # Regime banner in email
    regime_html = ""
    if regime and regime.get("regime") != "unknown":
        rcolor = "#2d6a2d" if "bull" in regime["regime"] else ("#8b1a1a" if "bear" in regime["regime"] or "correction" in regime["regime"] else "#7a6a00")
        regime_html = f'<div style="background:#1a1a2e;border-left:3px solid {rcolor};padding:12px 18px;border-radius:0 8px 8px 0;margin-bottom:16px;font-size:13px;color:#e8eaf0;"><strong style="color:{rcolor};">{regime["emoji"]} {regime["label"]}</strong> — {regime["summary"]}</div>'

    rows = ""
    for i, (_, row) in enumerate(top.iterrows()):
        score  = row["Consensus Score"]
        upside = row.get("Upside %", "n/a")
        bg_row = "#f9f9f9" if i % 2 == 0 else "white"
        sc, sb = ("#2d6a2d","#e6f4e6") if score >= 25 else (("#7a6a00","#fff8dc") if score >= 15 else ("#5f5e5a","#f1efe8"))
        try:
            uv = float(str(upside).replace("%",""))
            uc = "#2d6a2d" if uv >= 15 else ("#7a6a00" if uv >= 5 else "#8b1a1a")
        except Exception:
            uc = "#222"
        align_val = row.get("Alignment", "–")
        rows += f"""
        <tr style="background:{bg_row};">
          <td style="padding:8px 12px;font-weight:600;">{row['Ticker']} {row.get('New?','')} {row.get('Vol Spike','')}</td>
          <td style="padding:8px 12px;text-align:center;"><span style="background:{sb};color:{sc};padding:3px 10px;border-radius:12px;font-weight:600;">{int(score)}</span></td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Sources Agree','–')}</td>
          <td style="padding:8px 12px;text-align:center;font-size:11px;">{align_val}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Streak','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Yahoo SB','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Zacks #1','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Morningstar ★★★','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Insider Buy','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('EPS Rev ↑','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Beats S&P','–')}</td>
          <td style="padding:8px 12px;text-align:center;">${row.get('Price','–')}</td>
          <td style="padding:8px 12px;text-align:center;color:{uc};font-weight:600;">{upside}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Beta','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('Div Yield','–')}</td>
          <td style="padding:8px 12px;text-align:center;">{row.get('52w Position','–')}</td>
          <td style="padding:8px 12px;text-align:center;font-size:11px;">{row.get('Sector','–')}</td>
        </tr>"""

    warning_html = f'<p style="background:#fff3cd;padding:10px 14px;border-radius:4px;margin-bottom:12px;">{warning}</p>' if warning else ""

    html = f"""
    <html><body style="font-family:Arial,sans-serif;color:#222;max-width:960px;margin:auto;">
      <h2 style="color:#1a1a2e;margin-bottom:4px;">📈 Stock Convergence Report — {today}</h2>
      <div style="background:#1a1a2e;color:white;border-radius:8px;padding:12px 18px;margin-bottom:16px;font-size:13px;">
        S&P 500: <strong>{sp.get('price','n/a')}</strong> <span style="color:{sp_color};">{sp_arrow}{abs(sp_chg)}%</span>
        &nbsp;&nbsp; VIX: <strong>{vix.get('price','n/a')}</strong>
        &nbsp;&nbsp; 10yr: <strong>{tny.get('price','n/a')}%</strong>
      </div>
      {regime_html}
      {f'<div style="background:#161c2a;border-left:3px solid #c9a84c;padding:14px 18px;border-radius:0 8px 8px 0;margin-bottom:16px;font-size:13px;color:#e8eaf0;line-height:1.6;"><strong style="color:#c9a84c;font-size:11px;text-transform:uppercase;letter-spacing:0.08em;display:block;margin-bottom:6px;">AI Market Brief</strong>{ai_brief}</div>' if ai_brief else ""}
      {warning_html}
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#1a1a2e;color:white;">
          <th style="padding:10px 12px;text-align:left;">Ticker</th>
          <th style="padding:10px 12px;">Score</th><th style="padding:10px 12px;">Sources</th>
          <th style="padding:10px 12px;">Alignment</th><th style="padding:10px 12px;">Streak</th>
          <th style="padding:10px 12px;">Yahoo</th><th style="padding:10px 12px;">Zacks</th>
          <th style="padding:10px 12px;">MS</th><th style="padding:10px 12px;">Insider</th>
          <th style="padding:10px 12px;">EPS Rev</th><th style="padding:10px 12px;">Beats S&P</th>
          <th style="padding:10px 12px;">Price</th><th style="padding:10px 12px;">Upside</th>
          <th style="padding:10px 12px;">Beta</th><th style="padding:10px 12px;">Div</th>
          <th style="padding:10px 12px;">52w Pos</th><th style="padding:10px 12px;">Sector</th>
        </tr></thead>
        <tbody>{rows}</tbody>
      </table>
      <p style="font-size:11px;color:#888;margin-top:16px;">Not financial advice. Always do your own research.</p>
    </body></html>"""

    if not RESEND_KEY:
        print("  ✗ Email skipped: RESEND_KEY env var not set")
        return
    try:
        r = req.post(
            "https://api.resend.com/emails",
            headers={"Authorization": f"Bearer {RESEND_KEY}", "Content-Type": "application/json"},
            json={"from": EMAIL_FROM, "to": [EMAIL_TO],
                  "subject": f"📈 Stock Convergence Report — {today}", "html": html}
        )
        print(f"  ✓ Email sent" if r.status_code in (200,201) else f"  ✗ Email failed: {r.text}")
    except Exception as e:
        print(f"  ✗ Email error: {e}")

# ── daily job ─────────────────────────────────────────────────────────────────

def daily_job():
    print(f"\n{'='*55}\n  Daily Scan — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n{'='*55}")
    try:
        df, market, warning, alignments = run_analyzer()

        # AI market brief — generate before saving so dashboard gets it
        ai_brief = ""
        try:
            from features import generate_market_brief
            top_list = df.head(5).to_dict('records')
            ai_brief = generate_market_brief(top_list, market)
            market["ai_brief"] = ai_brief
            print(f"  ✓ AI market brief generated")
        except Exception as e:
            print(f"  ✗ AI brief error: {e}")

        # Market regime detection — generate before saving so dashboard gets it
        regime = None
        try:
            from market_regime import detect_market_regime
            top_stocks = df.head(20).to_dict('records')
            mapped = [{"score": r.get("Consensus Score", 0), "insider": r.get("Insider Buy", "–")} for r in top_stocks]
            regime = detect_market_regime(market, mapped)
            market["regime"] = regime.get("regime", "unknown")
            market["regime_label"] = regime.get("label", "")
            market["regime_confidence"] = regime.get("confidence", 0)
            print(f"  ✓ Market regime: {regime.get('label')} ({regime.get('confidence')}% confidence)")
        except Exception as e:
            print(f"  ✗ Regime detection error: {e}")

        # Save to web app database — now includes ai_brief + regime
        try:
            from app import save_scan_to_db, init_db
            init_db()
            save_scan_to_db(df, market)
            print("  ✓ Results saved to web app database")
        except Exception as e:
            print(f"  ✗ DB save failed: {e}")

        # Price alerts
        try:
            from features import check_price_alerts
            from database import get_db
            top_tickers = df.head(10)["Ticker"].tolist()
            conn = get_db()
            try:
                check_price_alerts(conn, top_tickers, RESEND_KEY, EMAIL_TO)
            finally:
                conn.close()
        except Exception as e:
            print(f"  ✗ Price alert error: {e}")

        save_to_drive(df)
        send_email(df, market, warning, ai_brief, regime)
        print(f"\n  ✓ Done! Next run at {RUN_TIME} UTC tomorrow.")
    except Exception as e:
        print(f"\n  ✗ Error: {e}")

# ── main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"""
╔══════════════════════════════════════════╗
║   Stock Convergence Scheduler  v3.2      ║
║   Runs daily at {RUN_TIME} UTC (7AM Pacific)  ║
║   Signal Alignment + Market Regime       ║
╚══════════════════════════════════════════╝
  Press Ctrl+C to stop.
    """)
    print("  Running first scan now...")
    daily_job()
    schedule.every().day.at(RUN_TIME).do(daily_job)
    print(f"\n  ✓ Scheduled for {RUN_TIME} UTC every day.")
    while True:
        schedule.run_pending()
        time.sleep(60)
